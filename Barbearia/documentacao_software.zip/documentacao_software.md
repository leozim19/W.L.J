`Replique esse documento e realize a atividade:`

# Documento de Projeto de Software

Desenvolvimento de um sistema << >> 

## Alunos envolvidos

- leonardo  - `Líder`
- walison 
- carlos 

*Corpo Inicial*

>Introdução
>
>Visão Geral do Projeto
>
>Premissas e Restrições
>
>Requisitos Funcionais e Requisitos Não Funcionais
>
>Layout/Prototipagem 


## Introdução

Com a utilização deste sistema web, é possivel propocionar a uma empresa o melhor controle de seus clientes, facilitando o desenvolvimento de uma Barbearia local!.

## Visão Geral do Projeto

Nosso sistema vai facilitar tanto para o publico e para a empresa, vai ta disposto para o usuarioa marcar horario com um estilo de corte selecionado no sistema da Barbearia, com nosso formulario de cadastro com informações importantes!,

## Premissas e Restrições

### Atores

Administrador, clientes, funcionarios(barbeiros).

### Regras de Negócios

O sistema permite qualquer pessoa que queira realizar uma reserva para cortar o cabelo, basta fazer o formulario.  Parte do sistema para ver as reserva que ocorreram  permite somente funcionarios da Barbearia. 

## Requisitos Funcionais e Requisitos Não Funcionais

### Requisitos Funcionais

|ID| home -
|RF01|tela com tudo sobre a Empresa
|ID_2| Produtos -
|RF02|tela com descrição sobre oque a Barbearia oferece e preço
|ID_3| contato -
tela de formulario  para preencher a reserva

### Requisitos Não Funcionais
#### Exemplo

|ID| mysql
|RNF01|controle do banco de dados so vai ter acesso os funcionarios da empresa

|ID| mysql
|RNF02|controle do banco de dados so vai ter acesso os funcionarios da empresa, para cancelar uma reserva e para visualizar

## Layout/Prototipagem 

Insira nesta seção as possíveis telas do sistema ou o esboço do sistema, como preferir.

`É importante descrever um pouco o fluxo de cada tela.`

#### Exemplo 1 

<p align="center">
  <img src="imagem.png" width="800" alt="">
</p>

#### Exemplo 2 

<p align="center">
  <img src="imagem2.png" width="800" alt="">
</p>

#### Exemplo 3 

<p align="center">
  <img src="imagem3.jpg" width="800" alt="">
</p>
